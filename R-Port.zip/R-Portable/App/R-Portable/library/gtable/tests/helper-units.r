cm <- unit(1, "cm")
cm2 <- unit(2, "cm")
cm5 <- unit(5, "cm")

null <- unit(1, "null")
