/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 196867
#define R_NICK "Smooth Sidewalk"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "1.3"
#define R_STATUS ""
#define R_YEAR   "2015"
#define R_MONTH  "03"
#define R_DAY    "09"
#define R_SVN_REVISION 67962
#define R_FILEVERSION    3,13,67962,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
